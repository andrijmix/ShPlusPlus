package com.shpp.p2p.cs.amikhnevych.assignment6.tm;

public class ToneMatrixLogic {
    /**
     * Given the contents of the tone matrix, returns a string of notes that should be played
     * to represent that matrix.
     *
     * @param toneMatrix The contents of the tone matrix.
     * @param column     The column number that is currently being played.
     * @param samples    The sound samples associated with each row.
     * @return A sound sample corresponding to all notes currently being played.
     */
    public static double[] matrixToMusic(boolean[][] toneMatrix, int column, double[][] samples) {
        double[] result = new double[ToneMatrixConstants.sampleSize()];
        for (int row = 0; row < toneMatrix.length; row++) {
            if (toneMatrix[row][column]) {
                for (int i = 0; i < samples[row].length; i++) { //add the note from the column place
                    result[i] += samples[row][i];
                }
            }
        }
        return NormalizeValue(result);
    }

    /**
     * Normalize array in range of [-1, 1]
     *
     * @param result - no normalized values
     * @return - normalized array
     */
    private static double[] NormalizeValue(double[] result) {
        double maxElement = getMaxElement(result); // get max Element
        if (maxElement != 0) { // if we have no empty elements then normal it
            for (int i = 0; i < result.length; i++) {
                result[i] /= maxElement;
            }
        }
        return result;
    }

    /**
     * Returns the maximum element of the array
     *
     * @param result final array where the maximum element
     * @return max element
     */
    private static double getMaxElement(double[] result) {
        double maxElement = Math.abs(result[0]);
        for (double v : result) {
            if (Math.abs(v) > maxElement) { // we work with abs value
                maxElement = Math.abs(v);
            }
        }
        return maxElement;
    }
}
